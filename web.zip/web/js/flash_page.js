document.write("<div style=\"width:960px; height:150px; background-image:url(1/031.jpg); overflow:hidden;\">");

document.write('<embed height="170" width="960" flashvars="bannerWidth=960&bannerHeight=170&bannerSID=http://gbm.alicdn.com/tfscom/T1Hz.LFq0aXXXgzXjX.xml&bannerXML=&bannerLink=http://&dataSource=&bid=38818295&appSource=default" wmode="transparent" allowscriptaccess="always" quality="high" name="38818295" id="38818295" style="" src="http://img.uu1001.cn/bcv3.swf?v=20140327-110551" type="application/x-shockwave-flash"/></embed>');

document.write("</div>");