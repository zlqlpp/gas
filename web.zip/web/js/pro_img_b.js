document.write('<div style="background-image:url(/images/mbacks.jpg ); height:17px; width:100%; margin-top:50px;">&nbsp;</div>');
