
document.write("<div style=\"margin:0 auto; width:960px; height:28px; background-color:#F7F3F7; overflow:hidden;\">");
document.write("<ul class=\"top0_ul\" style=\"margin:0; padding:0; float:left; margin-top:5px;\">");
document.write("<li><a href='http://www.chinagas.cn'>�й�����</a></li>");
document.write("<li><a href='http://www.chinagas.cn'>��ҵ��Ѷ</a></li>");
document.write("<li><a href=\"http://www.chinagas.cn\">������Ϣ</a></li>");

document.write("<li style=\"background-color:#fff;\"><a href=\"\">��˾չʾ</a></li>");
document.write("<li><a href='http://www.chinagas.cn'>ѧϰ����</a></li>");
document.write("<li><a href='http://www.chinagas.cn'>������̳</a></li>");
document.write("</ul>");
document.write("<div style=\" width:200px; float:right; margin-top:6px;\">");


document.write("<IMG style=\"CURSOR: hand\" onclick=\"window.location.href='index.htm';\"   height=15  src=\"/images/topsm01.gif\" width=42 border=0>");
document.write("<IMG style=\"CURSOR: hand\"  onclick=\"this.style.behavior='url(#default#homepage)';this.setHomePage('http://www.chinagases.cn/');return(false)\"   height=15  src=\"/images/topsm02.jpg\"  width=60 border=0>");
document.write("<IMG style=\"CURSOR: hand\" onclick=\"window.external.AddFavorite('http://www.chinagases.cn','�������ջ����������޹�˾')\" height=15  src=\"/images/topsm03.jpg\"  width=76 border=0>");

document.write("</div>");
document.write("</div>");
document.write("<div style=\"border-bottom:solid 0px gray; width:100%; height:90px; text-align:center;\">");

document.write('<OBJECT codeBase=http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0  height=90 width=960 classid=clsid:D27CDB6E-AE6D-11cf-96B8-444553540000>');
document.write('<PARAM NAME="movie" VALUE="/top.swf"><PARAM NAME="quality" VALUE="high">');
document.write('<param name="wmode" value="transparent">');
document.write('<embed src="/top.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="960" height="90"></embed></OBJECT>');



document.write("</div>");